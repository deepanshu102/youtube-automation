#!/usr/bin/env python3
"""
Tech Community Trends Fetcher
Aggregates and filters trending topics for developers, AI/ML, DevOps communities
"""

import requests
import feedparser
import json
from datetime import datetime
from typing import List, Dict, Optional
import sys

class TechTrendsFetcher:
    """Fetch and filter tech-specific trends from multiple sources"""
    
    # Tech-specific keywords by community
    COMMUNITY_KEYWORDS = {
        'ai': [
            'ChatGPT', 'Claude', 'GPT-4', 'Gemini', 'LLM', 'machine learning',
            'neural network', 'transformer', 'DALL-E', 'stable diffusion',
            'langchain', 'vector database', 'RAG', 'fine-tuning'
        ],
        'web': [
            'React', 'Vue', 'Angular', 'Next.js', 'TypeScript', 'Node.js',
            'Remix', 'Svelte', 'CSS', 'JavaScript', 'Web3', 'PWA'
        ],
        'devops': [
            'Docker', 'Kubernetes', 'AWS', 'Azure', 'GCP', 'GitLab',
            'CI/CD', 'Terraform', 'Jenkins', 'Prometheus', 'Linux'
        ],
        'security': [
            'cybersecurity', 'penetration', 'encryption', 'vulnerability',
            'malware', 'zero-trust', 'OWASP', 'SSL/TLS', 'OAuth'
        ],
        'blockchain': [
            'Bitcoin', 'Ethereum', 'Web3', 'NFT', 'DeFi', 'smart contract',
            'Solidity', 'blockchain', 'crypto'
        ],
        'mobile': [
            'React Native', 'Flutter', 'Swift', 'Kotlin', 'iOS', 'Android',
            'Dart', 'Xcode', 'mobile development'
        ]
    }
    
    # RSS Feed URLs by source
    RSS_SOURCES = {
        'google_trends_us': 'https://trends.google.com/trending/rss?geo=US',
        'google_trends_tech': 'https://trends.google.com/trending/rss?geo=US&cat=1',
        'hackernews': 'https://news.ycombinator.com/rss',
        'dev_to': 'https://dev.to/api/articles/latest',
    }
    
    def __init__(self, timeout: int = 10):
        self.timeout = timeout
        self.trends = []
    
    def fetch_rss_feed(self, url: str, max_items: int = 20) -> List[Dict]:
        """Fetch and parse RSS feed"""
        try:
            feed = feedparser.parse(url)
            items = []
            
            for entry in feed.entries[:max_items]:
                item = {
                    'title': entry.get('title', 'N/A'),
                    'link': entry.get('link', ''),
                    'published': entry.get('published', datetime.now().isoformat()),
                    'source': feed.feed.get('title', 'Unknown'),
                }
                items.append(item)
            
            return items
        except Exception as e:
            print(f"Error fetching {url}: {e}", file=sys.stderr)
            return []
    
    def fetch_google_trends(self, country: str = 'US', category: Optional[str] = None) -> List[Dict]:
        """Fetch trends from Google Trends RSS"""
        if category:
            url = f'https://trends.google.com/trending/rss?geo={country}&cat={category}'
        else:
            url = f'https://trends.google.com/trending/rss?geo={country}'
        
        try:
            response = requests.get(url, timeout=self.timeout, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
            })
            response.raise_for_status()
            
            feed = feedparser.parse(response.content)
            trends = []
            
            for entry in feed.entries:
                trend = {
                    'title': entry.get('title', ''),
                    'traffic': entry.find('approx_traffic', entry).text if entry.find('approx_traffic') else 'N/A',
                    'link': entry.get('link', ''),
                    'source': 'Google Trends',
                    'timestamp': datetime.now().isoformat()
                }
                trends.append(trend)
            
            return trends
        except Exception as e:
            print(f"Error fetching Google Trends: {e}", file=sys.stderr)
            return []
    
    def filter_by_keywords(self, trends: List[Dict], keywords: List[str]) -> List[Dict]:
        """Filter trends by keywords"""
        filtered = []
        for trend in trends:
            title = trend.get('title', '').lower()
            if any(kw.lower() in title for kw in keywords):
                filtered.append(trend)
        return filtered
    
    def get_community_trends(self, community: str, country: str = 'US') -> List[Dict]:
        """Get trends for specific community"""
        if community not in self.COMMUNITY_KEYWORDS:
            print(f"Unknown community: {community}")
            print(f"Available: {', '.join(self.COMMUNITY_KEYWORDS.keys())}")
            return []
        
        keywords = self.COMMUNITY_KEYWORDS[community]
        all_trends = []
        
        # Fetch from Google Trends (category 1 = Computers & Electronics)
        google_trends = self.fetch_google_trends(country, category='1')
        all_trends.extend(google_trends)
        
        # Fetch from Hacker News
        hn_trends = self.fetch_rss_feed(self.RSS_SOURCES['hackernews'], max_items=30)
        all_trends.extend(hn_trends)
        
        # Filter by community keywords
        community_trends = self.filter_by_keywords(all_trends, keywords)
        
        return community_trends
    
    def aggregate_all_sources(self, max_per_source: int = 10) -> Dict:
        """Aggregate trends from all configured sources"""
        results = {}
        
        for source_name, url in self.RSS_SOURCES.items():
            print(f"Fetching {source_name}...", file=sys.stderr)
            trends = self.fetch_rss_feed(url, max_items=max_per_source)
            results[source_name] = trends
        
        return results
    
    def save_to_json(self, data: Dict, filename: str = 'tech_trends.json'):
        """Save trends to JSON file"""
        try:
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            print(f"Saved to {filename}")
        except Exception as e:
            print(f"Error saving to file: {e}", file=sys.stderr)
    
    def print_trends(self, trends: List[Dict], max_items: int = 10):
        """Pretty print trends"""
        print(f"\n{'='*80}")
        print(f"Found {len(trends)} relevant trends\n")
        
        for i, trend in enumerate(trends[:max_items], 1):
            print(f"{i}. {trend.get('title', 'N/A')}")
            print(f"   Source: {trend.get('source', 'N/A')}")
            print(f"   Link: {trend.get('link', 'N/A')}")
            print()


def main():
    """Main function"""
    fetcher = TechTrendsFetcher()
    
    # Example 1: Fetch AI trends
    print("Fetching AI/ML Community Trends...")
    ai_trends = fetcher.get_community_trends('ai', country='US')
    fetcher.print_trends(ai_trends)
    
    # Example 2: Fetch Web Dev trends
    print("\n\nFetching Web Development Trends...")
    web_trends = fetcher.get_community_trends('web', country='US')
    fetcher.print_trends(web_trends)
    
    # Example 3: Fetch DevOps trends
    print("\n\nFetching DevOps Community Trends...")
    devops_trends = fetcher.get_community_trends('devops', country='US')
    fetcher.print_trends(devops_trends)
    
    # Example 4: Aggregate all sources
    print("\n\nAggregating All Sources...")
    all_aggregated = fetcher.aggregate_all_sources(max_per_source=5)
    
    # Save to file
    output = {
        'timestamp': datetime.now().isoformat(),
        'ai_trends': ai_trends[:5],
        'web_trends': web_trends[:5],
        'devops_trends': devops_trends[:5],
        'aggregated_sources': all_aggregated
    }
    
    fetcher.save_to_json(output)


if __name__ == '__main__':
    # Check dependencies
    try:
        import feedparser
        import requests
    except ImportError:
        print("Installing required packages...")
        import subprocess
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'feedparser', 'requests'])
    
    main()
